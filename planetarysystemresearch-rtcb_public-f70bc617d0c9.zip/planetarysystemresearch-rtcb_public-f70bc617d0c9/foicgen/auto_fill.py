import generate_variables as r
reload(r)
c = r.Generate_variables()
c.generate_input_file0()

